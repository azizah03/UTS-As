<?php  
require_once 'koneksi.php';  
 
$query = "SELECT * FROM tb_data ORDER BY  kode_listrik"; 
 
$result = mysqli_query($konek,$query); 
 
$array = array(); 
 
while ($row  = mysqli_fetch_assoc($result)) 
{ 
 $array[] = $row;  
} 
 
 
echo ($result) ?  
json_encode(array("kode" => 1, "result"=>$array)) : 
json_encode(array("kode" => 0, "pesan"=>"data tidak ditemukan")); 
?>